INSERT INTO users (login, email, pass, sex, berd_date, name, sur_name) VALUES 
('Den_Pesdyk', 'den99@mail.com', '5Fktrctq', '1', '1995-10-17', 'Denis', 'Pisynov');

INSERT INTO users (login, email, pass, sex, berd_date, name, sur_name) VALUES 
('Serega', 'serega_gansta2003@mail.com', '5Fktrctq', '1', '2003-10-19', 'Serega', 'Vsehporvu');

INSERT INTO users (login, email, pass, sex, berd_date, name, sur_name) VALUES 
('Govno', 'em_kotyat95@govno.com', 'nikto_ne', '1', '1892-08-01', 'Oleg', 'Vidmanov');

INSERT INTO users (login, email, pass, sex, berd_date, name, sur_name) VALUES 
('Gansta', 'bandit95@google.com', 'blya_budu_gansta', '1', '2004-10-17', 'Misha', 'Zashekancev');

INSERT INTO users (login, email, pass, sex, berd_date, name, sur_name) VALUES 
('Zahar', 'xxxxx95@mail.com', '5Fkedtrctq', '0', '1995-01-17', 'Nastya', 'Astahova');

INSERT INTO users (login, email, pass, sex, berd_date, name, sur_name) VALUES 
('Klinskoe', 'boroda2000i++@yandex.ru', 'zakat', '0', '1994-01-15', 'Jana', 'Vidmanova');

INSERT INTO users (login, email, pass, sex, berd_date, name, sur_name) VALUES 
('Semen', 'radost97@rambler.com', 'pripyat', '0', '1993-08-01', 'Irina', 'Servernaya');

INSERT INTO users (login, email, pass, sex, berd_date, name, sur_name) VALUES 
('ZLO', 'evropagavno@yandex.ru', 'suukaaa', '0', '1971-10-17', 'Katerina', 'Golovogrizova');