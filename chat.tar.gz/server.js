var http = require('http');
var Static = require('node-static');
var mysql = require('mysql') ;

var WebSocketServer = new require('ws');

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'stalker',
  database : 'chat'
});

connection.connect();

function randomInteger(min, max) {
    var rand = min - 0.5 + Math.random() * (max - min + 1)
    rand = Math.round(rand);
    return rand;
}
function now(){
  var date = new Date();
  date = date.getHours().toString() + ":" + date.getMinutes().toString() + ":" + date.getSeconds().toString();
  return date;
}

var clients = {};
var webSocketServer = new WebSocketServer.Server({port: 8080});
webSocketServer.on('connection', function(ws){

  var id = Math.random();
  var idConection = id;
  clients[id] = [];
  clients[id][idConection] = ws; 
  
 
  
  console.log(now() + " Новое соединение: ID = " + id + ", IDConection  = " + idConection);

  ws.on('message', function(message) {
    
    message = JSON.parse(message);
    
    if(message["action"] == "registration" && id < 1){
      var regData = {
        "email": message["email"],
        "name": message["name"],
        "sur_name": message["sur_name"],
        "login": message["login"],
        "birth_day": message["birth_day"],
        "sex": "1",
        "password": message["password"]
      };
      var uniqRegSqlEmail = "SELECT * FROM users WHERE email='" + regData.email + "';";
      connection.query(uniqRegSqlEmail, function(err, rows, fields){
        if(!err){
          if(rows.length == 0){
            var uniqRegSqlLogin = "SELECT * FROM users WHERE login='" + regData.login + "';";
            connection.query(uniqRegSqlLogin, function(err, rows, fields){
              if(!err){
                if(rows.length == 0){
                  var sqlRegistration = "INSERT INTO users (login, email, pass, sex, berd_date, name, sur_name) VALUES ('" + regData.login + "', '" + regData.email + "', '" + regData.password + "', '" + regData.sex + "', '" + regData.birth_day + "', '" + regData.name + "', '" + regData.sur_name + "');";
                  connection.query(sqlRegistration, function(err, rows, fields){
                    if (!err){
                      var messageClient = {
                        "event": "registrationSucces"
                      };
                      console.log(now() + " Регистрация успешная: " + regData.email);
                      clients[id][idConection].send(JSON.stringify(messageClient));
                    }
                    else{
                      console.log('Error while performing Query. 1');
                      var messageClient = {
                        "event": "registrationFailed",
                        "details": "Ошибка регистрации. Проверьте данные"
                      };
                      clients[id][idConection].send(JSON.stringify(messageClient));
                      //
                    }
                  });
                }
                else{
                  var messageClient = {
                    "event": "registrationFailed",
                    "details": "Пользователь с данным логином уже зарегистрирован."
                  };
                  console.log(now() + " Данный логин есть в базе");
                  clients[id][idConection].send(JSON.stringify(messageClient));

                }
              }
              else{
                var messageClient = {
                  "event": "registrationFailed",
                  "details": "Ошибка сервера."
                };
                console.log(now() + " Registration: Error while performing Query.5");
                clients[id][idConection].send(JSON.stringify(messageClient));
              }
            });
          }
          else{
              var messageClient = {
                "event": "registrationFailed",
                "details": "Пользователь с данным E-mail уже зарегистрирован."
              };
              console.log(now() + " такой email есть базе");
              clients[id][idConection].send(JSON.stringify(messageClient));
            }
        }
        else{
          console.log(now() + " Registration: Error while performing Query.6");
          var messageClient = {
              "event": "registrationFailed",
              "details": "Ошибка сервера."
            };
              clients[id][idConection].send(JSON.stringify(messageClient));
            
        }
      });      
    }
    if(message["action"] == "athorization" && id < 1){

        console.log(now() + ' Попытка авторизации: ID = ' + id);
          var dbQuery = "SELECT * from users WHERE email='" + message["login"] + "'";
          var params = [];
            params["id"] = id;
            params["login"] = message["login"];
            params["password"] = message["password"];
          connection.query(dbQuery, params, function(err, rows, fields){
            if (!err){
              if(rows.length > 0){

                if(rows[0]["pass"] == params["password"]){
                  console.log(now() + " Пользователь залогинился:");
                   console.log("--**--**-- ID: " + params["id"]);
                   console.log("--**--**-- E-mail: " + params["login"]);
                   console.log("--**--**-- Password: " + params["password"]);
                   //Есть ли уже залогиненые устройсива для этого аккаунта
                   if(clients[rows[0]["id"]] == undefined){
                    //var randomID = randomInteger(0, 100);
                    clients[rows[0]["id"]] = []; 
                    clients[rows[0]["id"]][0] = clients[id][idConection];
                    idConection = 0;
                    delete clients[id];
                    id = rows[0]["id"];
                    console.log("нет залогиненыx");                    
                  }
                  else{
                    newIdConection = clients[rows[0]["id"]].length;
                    clients[rows[0]["id"]][newIdConection] = clients[id][idConection];
                    idConection = newIdConection;
                    delete clients[id];
                    id = rows[0]["id"];
                    console.log("Есть залогиненые");
                  }

                  var messClient = {
                    "event": "authorizationSucces",
                    "userData": {
                      "id": rows[0]["id"],
                      "name": rows[0]["name"],
                      "sur_name": rows[0]["sur_name"],
                      "sex": rows[0]["sex"],
                      "birth_day": rows[0]["berd_date"]
                    }                    
                  };

                  //Ищем друзей юзера
                  var resultFriends = [];
                  function resultFriendsSender(){
                      
                      messClient["userFriends"] = resultFriends;
                      clients[id][idConection].send(JSON.stringify(messClient));
                  }
                  var userID = rows[0]["id"];
                  var dbQuery = "SELECT * FROM friends WHERE (friend_1='" + userID + "' OR friend_2='" + userID + "') AND status='1';";
                  connection.query(dbQuery, function(err, rows, fields){
                    if (!err){
                      var friendID = '';
                      if(rows.length != 0){
                      rows.forEach(function(item, i, arr) {
                        if(item["friend_1"] == userID){
                          friendID = item["friend_2"];
                        }
                        else{
                          friendID = item["friend_1"];
                        }
                        
                        var length = arr.length;

                        var dbQuery = "SELECT * FROM users WHERE id='" + friendID + "';";
                        connection.query(dbQuery, length, function(err, rows, fields){
                          if (!err){
                            resultFriends.push(rows[0]);
                            if(resultFriends.length == length){
                              resultFriendsSender();
                              
                            }
                          }
                          else{
                            console.log('Error while performing Query.');
                          }
                        });
                      });
                      }
                      else{
                        resultFriendsSender();
                      }
                    }
                    else{
                      console.log('Error while performing Query.');
                    }
                  });
                  //clients[params["id"]].send(JSON.stringify(messClient));
                }
                else{
                   console.log(now() + " Пользователь ввел не верный пароль:");
                   console.log("--**--**-- ID: " + params["id"]);
                   console.log("--**--**-- E-mail: " + params["login"]);
                   console.log("--**--**-- Password: " + params["password"]);
                   var messClient = {
                    "event": "authorizationFailed",
                    "details": "Неверный пароль"
                  };
                  clients[id][idConection].send(JSON.stringify(messClient));
                }
              }
              else{
                console.log("user not found");
                var messClient = {
                    "event": "authorizationFailed",
                    "details": "Пользователь не найден"
                  };
                  clients[id][idConection].send(JSON.stringify(messClient));
              }          
    
            }   
            else{    
              console.log('Error while performing Query.');
            }

          });
    }
    if(message["action"] == "sendMessage"){
        if(clients[message["to_user_id"]] != undefined){

        
          var dataOutToClient = {
            "event": "messageNew",
            "from_user_id": id,
            "text_message": message["text_message"],
            "date_time": now()
          };
          clients[message["to_user_id"]].forEach(function(item, i, arr){
            item.send(JSON.stringify(dataOutToClient));
            console.log(i);
          });

          
        }
        console.log(message["text_message"] + " " + message["to_user_id"]);
    }    
  });
  ws.on('close', function() {
    console.log(now() + ' Cоединение закрыто: ID = ' + id + ', IDConection = ' + idConection);
    delete clients[id][idConection];
    console.log(clients[id]);
  });
});

var fileServer = new Static.Server('public');
http.createServer(function (req, res) {
  
  fileServer.serve(req, res);

}).listen(80);
console.log(now() + "Сервер запущен на портах 8080");
