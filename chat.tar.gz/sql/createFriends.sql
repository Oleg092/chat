CREATE TABLE friends (
id int(11) AUTO_INCREMENT,
friend_1 int(11) NOT NULL,
friend_2 int(11) NOT NULL,
status char(1) NOT NULL,
PRIMARY KEY (id));
