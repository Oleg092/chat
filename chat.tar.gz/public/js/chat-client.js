if (!window.WebSocket) {
	$("#errorModalNoneWS").modal();
}
var socketPort = 8080;
var socketServer = "localhost";
var socket = new WebSocket("ws://" + socketServer + ":" + socketPort + "/");

//var userMessages = [];
var userFriends = [];
var user = {};
var currentFriendDialog = 0;
var activePage = "";

function now(){
  var date = new Date();
  date = date.getHours().toString() + ":" + date.getMinutes().toString() + ":" + date.getSeconds().toString();
  return date;
}

socket.onmessage = function(event) {
	//Обработка входящих сообщения
	var message = JSON.parse(event.data);
  	if(message["event"] == "authorizationSucces"){
  		authorizationSucces(message["userData"], message["userFriends"]);
  	}
  	if(message["event"] == "authorizationFailed"){
  		authorizationFailed(message);
  	}
  	if(message["event"] == "registrationSucces"){
  		alert("Вы успешно зарегистрировались");
  	}
  	if(message["event"] == "registrationFailed"){
  		registrationFailed(message);
  	}
  	if(message["event"] == "messageNew"){
  		//alert(message["text_message"]);
  		messageNew(message);
  	}
  	if(message["event"] == "friendOnline"){

  	}
  	if(message["event"] == "friendOfline"){

  	}
  
};
 $('form').submit(function() {return false;});
 $('#sendMessageButton').click(function(){
 	var text = $('#textMessageArea').val();
 	if(text != ""){
 	$('#textMessageArea').val('');
 	var user_id = currentFriendDialog;
 		sendMessage(user_id, text);
 	}
 	var div = $("#messageBox");
	div.scrollTop(div.prop('scrollHeight') + 200);
 });
//Функция авторизации
function authorization(){
	var login = $("#inputEmail").val();
	var pass = $("#inputPassword").val();
	var data = {
		"action": "athorization",
		"login": login,
		"password": pass
	};
	socket.send(JSON.stringify(data));
	
}
function registration(){
	
	var email = $("#inputEmailReg").val();
	var name = $("#inputNameReg").val();
	var sur_name = $("#inputSurNameReg").val();
	var login = $("#inputLoginReg").val();
	var sex = $("#inputSexReg").val();
	var birth_day = $("#inputBDReg").val();
	var password = $("#inputPasswordReg").val();

	var dataRegObj = {
		"action": "registration",
		"email": email,
		"name": name,
		"sur_name": sur_name,
		"login": login,
		"sex": sex,
		"birth_day": birth_day,
		"password": password
	};
	socket.send(JSON.stringify(dataRegObj));
}
function sendMessage(user_id, text){
	var data = {
		"action": "sendMessage",
		"to_user_id": user_id,
		"text_message": text
	};
	var messageNewHtml = "<div class='message row'><div class='messageAvatar col-md-1'><img src='" + user.mini + "'></div><div class='messageText col-md-10'>" + text + "</div><div class='messageTime col-md-1'>" + now() + "</div></div>";
	$("#mbf" + currentFriendDialog).append(messageNewHtml);
	
	socket.send(JSON.stringify(data));	
}
//Смена страницы

$(".page-link").click(function(){
	var idLink = $(this).attr("id");
	idLink = idLink.substr(0, idLink.length - 4);
	tooglePage(idLink);
});

//Функция вызывается при успешной авторизации
function authorizationSucces(userData, uFriends){
	
	$("#signInButton").remove();
	activePage = "pageProfile";
	$("#" + activePage + "Link").addClass("currentPageLink");
	
	user.id = userData.id;
	user.name = userData.name;
	user.sur_name = userData.sur_name;
	user.sex = userData.sex;
	user.birth_day = userData.birth_day.substr(0,10);
	if(user.sex == "1"){user.sexText = "мужской"}
	else{user.sexText = "женский"}
	user.avatar = "./avatars/user" + userData.id + ".jpg";
	user.mini = "./avatars/mini/user" + userData.id + ".jpg";
	userFriends = uFriends;

	if(userFriends != undefined){
	toogleDialog(userFriends[0]["id"]);
	//alert(userFriends[2]["name"]);
	}

	//Формирование профиля юзера
	var profileHTML = "<img src='" + user.avatar + "'><p>Имя: " + user.name +"</p><p>Фамилия: " + user.sur_name +"</p><p>Пол: " + user.sexText + "</p><p>Дата рождения: " + user.birth_day + "</p>";
	$("#pageProfile").html(profileHTML);

	$("#authorizeModal").modal('hide');
	$("#main").removeClass("cHidden");
	//$("#startPage").addClass("cHidden");
	$("#startPage").remove();



	//Формирования списка друзей на странице друзья и странице сообщения
	var friendsHtmlpage = "";
	var friendsHtmlList = "";
	var messageBoxFriend = "";
	if(userFriends.length == 0){
		friendsHtmlList = "Вы наверное, Ларин? И у вас нет друзей";
		friendsHtmlpage = "Вы наверное, Ларин? И у вас нет друзей";
	}
	else{
	for(var i = 0; i < userFriends.length; i++){
		friendsHtmlpage = friendsHtmlpage + "<div class='row'><div class='col-md-2'><img src='./avatars/user" + userFriends[i].id + ".jpg'></div><div class='col-md-10'>" + userFriends[i].name + " " + userFriends[i].sur_name + "</div></div>";
		friendsHtmlList = friendsHtmlList + "<li><a href='#' id='user" + userFriends[i].id + "' class='friendListLink'><img src='./avatars/mini/user" + userFriends[i].id + ".jpg'>" + userFriends[i].name + " " + userFriends[i].sur_name + "</a></li>";
		messageBoxFriend = messageBoxFriend + "<div id='mbf" + userFriends[i].id + "' class='messageBoxFriend cHidden'></div>";
	}
	}
	$('#friendListUL').html(friendsHtmlList);
	$('#friendListBoxPage').html(friendsHtmlpage);
	$('#messageBox').html(messageBoxFriend);
	$("#messageEditorAvaUsers").html("<img src='" + user.mini + "' class='avatar64'>");
	$(".friendListLink").click(function(){
		var idLink = $(this).attr("id");
		

		if(currentFriendDialog != 0){
			$("#user" + currentFriendDialog).removeClass("currentFriendDialogLink");
		}
		$(this).addClass("currentFriendDialogLink");
		idLink = idLink.substr(4, idLink.length - 4);
		
		toogleDialog(idLink);
	});

	

}
//Смена диалога
function toogleDialog(id_friend){
	for(var i = 0; i < userFriends.length; i++){
		if(userFriends[i].id == id_friend){
			$(".currentDialogFname").html(userFriends[i].name + " " + userFriends[i].sur_name);		
		}
	}
	if(currentFriendDialog != 0){
		$("#mbf" + currentFriendDialog).addClass("cHidden");	
	}
	$("#mbf" + id_friend).removeClass("cHidden");
	currentFriendDialog = id_friend;
	$("#messageEditorAvaUsersFriendsImg").attr('src', './avatars/mini/user' + id_friend + '.jpg');

}
//Смена страницы

function tooglePage(name_page){
	
	$("#"+ activePage).addClass("cHidden");
	$("#" + name_page).removeClass("cHidden");
	$("#" + activePage + "Link").removeClass("currentPageLink");
	$("#" + name_page + "Link").addClass("currentPageLink");
	activePage = name_page;
}
//Функция вызывается при неуспешной авторизации
function authorizationFailed(message){
	//alert("Ошибка! Вы не авторизованы!");
	$("#infoAuthorize").removeClass("cHidden");
	$("#infoAuthorize").html(message.details);
}
function registrationFailed(message){
	$("#infoRegistration").removeClass("cHidden");
	$("#infoRegistrationP").html(message.details);
}
function messageNew(message){
	//Внесение сообщения в массив сообщений
	var messageNewHtml = "<div class='message row'><div class='messageAvatar col-md-1'><img src='./avatars/mini/user" + message.from_user_id + ".jpg'></div><div class='messageText col-md-10'>" + message.text_message + "</div><div class='messageTime col-md-1'>" + message.date_time + "</div></div>";
	$("#mbf" + message.from_user_id).append(messageNewHtml);
	var div = $("#messageBox");
	div.scrollTop(div.prop('scrollHeight') + 200);
	document.getElementById('audio').play();
}